from flask import Flask, render_template, request, redirect
app = Flask(__name__)

# Root Route
@app.route('/')
def root_route():
    return render_template('index.html')
# app.run(debug=True)

# Ninjas
@app.route('/ninjas')
def ninja_info():
    return render_template('ninjas.html')
# app.run(debug=True)

# Dojos
@app.route('/dojos/new')
def dojos_info():
    return render_template('dojos.html')
app.run(debug=True)