from flask import Flask, render_template, redirect, request, session
import random
app = Flask(__name__)

app.secret_key= 'ItsASecretDuh'

@app.route('/')
def index():
    if 'number' not in session:
        session['number'] = random.randrange(1,101)
    print session['number']
    return render_template('index.html')

@app.route('/guess', methods=['POST'])
def guess():
    user_guess = int(request.form['guess'])
    print user_guess
    print session['number']
    if user_guess > session['number']:
        return render_template('toohigh.html', number=session['number'], guess=user_guess)
    if user_guess < session['number']:
        return render_template('toolow.html', number=session['number'], guess=user_guess)
    if user_guess == session['number']:
        return render_template('gotit.html', number=session['number'], guess=user_guess)

@app.route('/reset')
def reset():
    session.pop('number')
    return redirect('/')

app.run(debug=True)