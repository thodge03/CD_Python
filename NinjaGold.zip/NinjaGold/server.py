from flask import Flask, render_template, redirect, request, session, url_for
app = Flask(__name__)

app.secret_key= 'ItsASecretDuh'
import random
import datetime

@app.route('/')
def index():
    if 'total_gold' not in session:
        session['total_gold'] = 0
    if 'activity' not in session:
        session['activity'] = []
    # session['total_gold'] += 15
    return render_template('index.html')

@app.route('/process_money', methods=['POST'])
def process():
    building = request.form['building']
    if building == 'farm':
        gold = random.randint(10,20)
        session['total_gold'] += gold
        session['activity'].append({
            "event":'Earned ' + str(gold) + ' gold from the farm. ' + str(datetime.datetime.now()),
            "won":True
        })
    elif building == 'cave':
        gold = random.randint(5,10)
        session['total_gold'] += gold
        session['activity'].append({
            "event":'Earned ' + str(gold) + ' gold from the cave. ' + str(datetime.datetime.now()),
            'won':True
        })
    elif building == 'house':
        gold = random.randint(2,5)
        session['total_gold'] += gold
        session['activity'].append({
            "event":'Earned ' + str(gold) + ' gold from the house. ' + str(datetime.datetime.now()),
            'won':True
        })
    elif building == 'casino':
        chance = random.randint(1,2)
        gold = random.randint(0,50)
        if chance == 1:
            session['total_gold'] -= gold
            session['activity'].append({
                "event":'Lost ' + str(gold) + ' gold from the casino..Sorry! ' + str(datetime.datetime.now()),
                "won":False
            })
        else:
            session['total_gold'] += gold
            session['activity'].append({
                "event":'Earned ' + str(gold) + ' gold from the casino. ' + str(datetime.datetime.now()),
                "won":True
            })
    
    print session['activity']
    return redirect('/')

@app.route('/clear')
def clear_session():
    session.clear()
    return redirect('/')

app.run(debug=True)