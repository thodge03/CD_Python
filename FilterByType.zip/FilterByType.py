sI = 45
mI = 100
bI = 455
eI = 0
spI = -23
sS = "Rubber baby buggy bumpers"
mS = "Experience is simply the name we give our mistakes"
bS = "Tell me and I forget. Teach me and I remember. Involve me and I learn."
eS = ""
aL = [1,7,4,21]
mL = [3,5,7,34,3,2,113,65,8,89]
lL = [4,34,22,68,9,13,3,5,7,9,2,12,45,923]
eL = []
spL = ['name','address','phone number','social security number']

a = [sI, mI, bI, eI, spI, sS, mS, bS, eS, aL, mL, lL, eL, spL]
print a

for j in range(0,len(a)):
    if isinstance(a[j], float) | isinstance(a[j], int) == True:
        #if the list item at index a[0],a[1],etc is an integer or float:
        if a[j] >= 100:
            print "That's a big number!"
        else:
            print "That's a small number"
        j = j + 1
    elif isinstance(a[j], str) == True:
        #if the list item at index a[0],a[1],etc is a string:        
        if len(a[j]) >= 50:
            print 'Long sentence.'
        else:
            print 'Short sentence.'
        j = j + 1
    # elif isinstance(a[j], list) == True: >>(long-winded, there are no other options after int, float, & str, so if list:)
    else:
        if len(a[j]) >= 10:
            print 'Big list!'
        else:
            print 'Short list.'
        j = j + 1