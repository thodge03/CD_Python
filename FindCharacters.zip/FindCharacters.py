# input
word_list = ['hello','world','my','name','is','Anna','too','sweet','good']
char = 'o'
# output
new_list = []

def check_letter(lst,char):
    for item in lst:
        if char in item:
            new_list.append(item)
    print new_list

check_letter(word_list,char)