#Compare two lists, if they are identical print "These lists are the same", if not print "These lists are not the same"

list_one = [1,2,5,6,2]
list_two = [1,2,5,6,2]

# list_one = [1,2,5,6,5]
# list_two = [1,2,5,6,5,3]

# list_one = [1,2,5,6,5,16]
# list_two = [1,2,5,6,5]

# list_one = ['celery','carrots','bread','milk']
# list_two = ['celery','carrots','bread','cream']


def list_compare(list_one, list_two):
    if list_one == list_two:
        print 'These lists are the same'
    else:
        print 'These lists are not the same'


list_compare(list_one,list_two)