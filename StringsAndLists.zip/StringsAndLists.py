#Find and Replace
words = "It's thanksgiving day. It's my birthday,too!"
print words.find('day')
wordsnew = words.replace('day','month')
print wordsnew
# print words.replace('day','month')

# Min and Max
x = [2,54,-2,7,12,98]
print min(x)
print max(x)
# #OR!!
mymax = x[0]
mymin = x[0]
for y in range(0,len(x)):
    if x[y] > mymax:
        mymax = x[y]
        y = y + 1
print mymax

for i in range(0,len(x)):
    if x[i] < mymin:
        mymin = x[i]
        i = i + 1
print mymin

# First and Last
x = ['hello',2,54,-2,7,12,98,'world']
y = x[0]
z = x[len(x)-1]
a = [y,z]
print y
print z
print a

# New List
x= [19,2,54,-2,7,12,98,32,10,-3,6]
x.sort()
print x

b = x[:len(x)/2]
c= x[len(x)/2:]
print 'first list is', b
print 'second list is', c
print 'new list is', [b] + c