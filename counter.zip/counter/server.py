from flask import Flask, render_template, request, redirect, session
app = Flask(__name__)

app.secret_key = 'ThisIsSecret'

@app.route('/')
def index():
    if 'count' in session:
        session['count'] += 2
    else:
        session['count'] = 1
    return render_template('index.html', count=session['count'])

@app.route('/plus2')
def plus2():
    return redirect('/')

@app.route('/clear')
def clear():
    session.clear()
    return redirect('/')
# When clicking the button, the program runs through this route, resetting to 1 and then starting over with '/'.

app.run(debug=True)
