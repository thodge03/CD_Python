from flask import Flask, render_template, request, redirect
app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/ninja')
def group_photo():
    return render_template('turtles.html')

@app.route('/ninja/blue')
def turtlesblue():
        return render_template('leonardo.html')
# I figured it out!!
@app.route('/ninja/orange')
def turtlesorange():
        return render_template('michelangelo.html')
@app.route('/ninja/red')
def turtlesraph():
        return render_template('raphael.html')
@app.route('/ninja/purple')
def turtlesdon():
        return render_template('donatello.html')
@app.route('/ninja/<color>')
def turtles(color):
        return render_template('notapril.html', color = color)

app.run(debug=True)