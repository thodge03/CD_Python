# # Multiples
# # Part I - Write code that prints all the odd numbers from 1 to 1000. Use the for loop and don't use a list to do this exercise.
for i in range(1,1001):
    if i % 2 == 1:
        print i
        i = i + 2
# #or
for b in range(1,1001,2):
    print b


# # # Part II - Create another program that prints all the multiples of 5 from 5 to 1,000,000.
for j in range(5,1000001):
    if j % 5 == 0:
        print j
        j = j + 5

# # #or
for a in range(5,1000001,5):
    print a

# # # Sum List
# # # Create a program that prints the sum of all the values in the list: a = [1, 2, 5, 10, 255, 3]
a = [1,2,5,10,255,3]
sum = 0
for k in range(0,len(a)):
    sum = sum + a[k]
    k = k + 1
print sum

#or
for c in a:
    sum += c
print sum

# # Average List
# # Create a program that prints the average of the values in the list: a = [1, 2, 5, 10, 255, 3]
avg = sum / len(a)
print avg