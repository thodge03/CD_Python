from flask import Flask, render_template, redirect, request, session, flash
app = Flask(__name__)

app.secret_key='SecretsSecretsAreNoFun'

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/result', methods=['POST'])
def results(name=None,location=None,language=None,comments=None):
    print 'Got Survey Info'
    name = request.form['name']
    location = request.form['location']
    language = request.form['language']
    comments = request.form['comments']
    if len(name) < 1:
        if len(comments) < 1 or len(comments) > 120:
            flash('Name field cannot be empty! Comment field must be between 1 and 120 characters!')
            return redirect('/')
        else:
            flash('Name field cannot be empty!')
            return redirect('/')
    else:
        if len(comments) < 1 or len(comments) > 120:
            flash('Comment field must be between 1 and 120 characters!')
            return redirect('/')
        else:
            return render_template('result.html',name=name,location=location,language=language,comments=comments)
app.run(debug=True)